#Exercise Set 13 Create a dictionary with 3 sports as keys and the number of players per team as values. Print all the values of the dictionary.

sports : dict = {
    'cricket': 14,
    'hockey': 11,
    'badminton': 2
}

print(sports.values())