#Exercise Set 4 Create a dictionary with 3 cities as keys and their populations (in millions) as values. Print the population of the second city.

population : dict = {
    'Karachi' : '20,382,881',
    'Shanghai' : '21,909,814',
    'Istanbul' : '15,907,951',
}
data = "Shanghai has" + " " + population['Shanghai'] + " " + "million population."
print(data)