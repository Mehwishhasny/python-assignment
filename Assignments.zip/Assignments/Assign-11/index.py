#Exercise Set 11 Create a list of dictionaries where each dictionary represents a book with keys 'title' and 'pages'. Add 4 books and print the title of the third book

books = [
    {'title': 'War and Peace', 'pages': 500},
    {'title': 'The Count of Monte Cristo', 'pages': 1245},
    {'title': 'Atlas Shrugged', 'pages': 1168},
    {'title': 'Ulysses', 'pages': 785}
]


print(books[2]['title'])