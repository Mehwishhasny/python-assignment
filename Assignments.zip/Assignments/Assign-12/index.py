#Exercise Set 12 Create a list with 5 subjects. Append 'Mathematics' to the end of the list and print the updated list.

subjects : list[str] = ['English', 'International Organizations', 'International Law', 'Statistics', 'Pak Studies']
subjects.append('Mathematics')
print(subjects)