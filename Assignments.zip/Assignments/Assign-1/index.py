# Exercise Set 1 Create a list containing the names of 5 fruits. Print the second fruit from the list.

fruits : list = ['Apple', 'Mango', 'Banana', 'Avacado', 'Pomegranate']
print(fruits[1])