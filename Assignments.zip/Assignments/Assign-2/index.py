#Exercise Set 2 Create a dictionary with 3 programming languages as keys and their creators as values. Print the creator of the first language.

languages : dict = {
 "C++" : "Bjarne Stroustrup",
 "JavaScript" : "Brendan Eich",
 "Python" : "Guido van Rossum",
}

print(languages['C++'])