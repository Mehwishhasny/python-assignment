#Exercise Set 3 Create a list of 4 integers. Print the sum of all numbers in the list.

numbers : list[int] = [2, 4, 6, 8]
print(sum(numbers))