#Exercise Set 5 Create a list of dictionaries where each dictionary represents a student with keys 'name' and 'age'. Add 3 students and print the age of the second student.

students : dict = [
    { 'name' : 'Mira', 'age' : 23 },
    {'name' : 'Sara','age' : 22 },
    {'name' : 'Ayra', 'age' : 20 }
]

print(students[1]['age'])