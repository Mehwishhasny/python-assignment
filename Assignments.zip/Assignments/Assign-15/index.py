#Exercise Set 15 Create a list with 7 days of the week. Remove the fifth day from the list and print the updated list.

days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
days.remove('Thursday')
print(days)