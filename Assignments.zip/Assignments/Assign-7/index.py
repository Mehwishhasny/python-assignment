#Exercise Set 7 Create a dictionary with 4 animals as keys and their average lifespan (in years) as values. Print all the keys of the dictionary

animals : dict = {

    'Lion': '15 years',
    'Panda': '20 years',
    'Horse': '30 years',
    'Monkey': '25 years'
}
print(animals.keys())