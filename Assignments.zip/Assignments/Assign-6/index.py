#Exercise Set 6 Create a list with 5 colors. Replace the third color with 'purple' and print the updated list

colors : list[str] = ['Yellow', 'Red', 'Blue', 'Pink', 'White']
colors.remove('Blue')
colors.insert(2, 'Purple')
print(colors)