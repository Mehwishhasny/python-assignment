#Exercise Set 10 Create a dictionary with 3 countries as keys and their capital cities as values. Print the capital of the third country.

countries : dict = {
    'Pakistan' : 'Islamabad',
    'UAE' : 'Abu Dhabi',
    'China' : 'Beijing'
}
print(countries['China'])