#Exercise Set 8 Create a list of dictionaries where each dictionary has keys 'product' and 'price'. Add 3 products and print the price of the first product.

data : dict = [
    {
        'product' : ['Mobile phone', 'Computer', 'Smartwatch'],
        'price' : [25000, 140000, 20000]
    },

     {
        'product' : ['Cream', 'Lotion', 'Lip balm'],
        'price' : [1500, 1000, 1200]
    },

     {
        'product' : ['Shirt', 'Jeans', 'Scarf'],
        'price' : [2500, 3000, 1800]
    },
]

print(data[0]['price'][0])