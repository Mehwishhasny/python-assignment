#Exercise Set 9 Create a list with 6 numbers. Print the last number from the list.

numbers : int = [1, 3, 5, 7, 9, 11]
print(numbers[-1])