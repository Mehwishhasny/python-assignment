#Exercise Set 14 Create a list of dictionaries where each dictionary represents a car with keys 'model' and 'year'. Add 3 cars and print the year of the last car.

cars = [
    {'model' : 'Corolla Hybrid 2025', 'year': 2025},
    {'model' : 'Tesla Model X', 'year' : 2022},
    {'model' : 'Porsche 911 Carrera Cabriolet', 'year': 2024}
]

print(cars[2]['year'])